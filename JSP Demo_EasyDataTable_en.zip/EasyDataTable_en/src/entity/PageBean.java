package entity;

import java.util.List;

public class PageBean {
	private List data;
	private int pageNo;
	private int rowPerPage;
	private int totalCount;
	public List getData() {
		return data;
	}
	public void setData(List data) {
		this.data = data;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getRowPerPage() {
		return rowPerPage;
	}
	public void setRowPerPage(int rowPerPage) {
		this.rowPerPage = rowPerPage;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public PageBean(List data, int pageNo, int rowPerPage, int totalCount) {
		super();
		this.data = data;
		this.pageNo = pageNo;
		this.rowPerPage = rowPerPage;
		this.totalCount = totalCount;
	}
	public PageBean() {
		super();
	}

	
	
}
